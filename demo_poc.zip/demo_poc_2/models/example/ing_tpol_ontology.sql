{{ config(
    file_format='parquet',
    unique_key='pol_id',
    materialized='table'
) }}


select *
from {{ source('dataverse_ing_mirror_temp','tpol') }}
